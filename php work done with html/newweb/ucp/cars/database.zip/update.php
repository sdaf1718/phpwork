<?php
// create database connection with username no password and database name
$con =mysqli_connect("localhost","root","","cars");?>

<?php
// we checking the data in the database with variable user
// selecting the data from database from id field and storing it in by fetching it in array
$userid = $session["userid"];
$result=$con->query ("select * from cars where id ='$user'");
$row=$result->fetch_array(MYSQLI_BOTH);

session_start();

$session["make"]=$row['make'];
$session["model"]=$row['model'];
$session["Reg"]=$row['Reg'];
$session["colour"]=$row['colour'];
$session["miles"]=$row['miles'];
$session["price"]=$row['price'];
$session["dealer"]=$row['dealer'];
$session["town"]=$row['town'];
$session["telephone"]=$row['telephone'];
$session["description"]=$row['description'];
$session["carindex"]=$row['carindex'];
$session["region"]=$row['region'];
$session["image"]=$row['image'];
$session["id"]=$row['id'];

?>

<?php
// then we are saying what we wnat to update and what fields in database
if (isset($_post['update'])) {
$updatemake =$_POST['make'];
$updatemodel =$_POST['model'];
$updateReg =$_POST['Reg'];
$updatecolour =$_POST['colour'];
$updatemiles =$_POST['miles'];
$updateprice =$_POST['price'];
$updatedealer =$_POST['dealer'];
$updatetown =$_POST['town'];
$updatetelephone =$_POST['telephone'];
$updatedescription =$_POST['description'];
$updatecarindex =$_POST['carindex'];
$updateregion =$_POST['region'];
$updateimage =$_POST['image'];
$updateid =$_POST['id'];
// then we updating the fields in the database which is the final  step
$sql=$con->query("update cars SET make='{$updatemake}',model='{$updatemodel}',Reg='{$updateReg}',colour='{$updatecolour}',miles='{$updatemiles}',price='{$updateprice}',dealer='{$updatedealer}',town='{$updatetown}',telephone='{$updatetelephone}',description='{$updatedescription}',carindex='{$updatecarindex}',region='{$updateregion}',image='{$updateimage}',id='{$updateid}' where userid=$user");
// then if successful we re-directing them to another page
header('location: update account.php');
}
?>
<html>
<head>
<link rel="stylesheet" type="text/css" href="register.css">
</head>



<body>

<div class="container"> </div>
<div class="header> </div>
<div class="leftbody"> </div>

<div class="formelement"> </div>
<div class="formelement"> </div>

<div class="rightbody"> 


<form id="form1" name="form1" method="post" action="">

  <p>
    <label for="make">make</label>
    <input type="text" name="make" id="make" />
  </p>
  <p>
    <label for="model">model</label>
    <input type="text" name="model" id="model" />
  </p>
  <p>
    <label for="Reg">Reg</label>
    <input type="text" name="Reg" id="Reg" />
  </p>
  <p>
    <label for="colour">colour</label>
    <input type="text" name="colour" id="colour" />
  </p>
  <p>
    <label for="miles">miles</label>
    <input type="text" name="miles" id="miles" />
  </p>
  <p>
    <label for="price">price</label>
    <input type="text" name="price" id="price" />
  </p>
  <p>
    <label for="dealer">dealer</label>
    <input type="text" name="dealer" id="dealer" />
  </p>
  <p>
    <label for="town">town</label>
    <input type="text" name="town" id="town" />
  </p>
  <p>
    <label for="telephone">telephone</label>
    <input type="text" name="telephone" id="telephone" />
  </p>
  <p>
    <label for="description">description</label>
    <input type="text" name="description" id="description" />
  </p>
  <p>
    <label for="carindex">carindex</label>
    <input type="text" name="carindex" id="carindex" />
  </p>
  <p>
    <label for="region">region</label>
    <input type="text" name="region" id="region" />
  </p>
  <p>
    <label for="image">image</label>
    <input type="text" name="image" id="image" />
  </p>
  <p>
    <label for="id">id</label>
    <input type="text" name="id" id="id" />
  </p>

  <p>
    <input type="submit" name="update" id="update" value="update" />
  </p>
</form> 
<div class="footer"> </div>
</div>
</body>
</html>