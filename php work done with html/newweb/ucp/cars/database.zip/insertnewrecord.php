

<?php
 $con =mysqli_connect("localhost","root","","cars");

if(isset($_POST["submit"]))
{
	
session_start();
$make = $_POST["make"];
$model = $_POST["model"];
$Reg = $_POST["Reg"];
$colour = $_POST["colour"];
$miles = $_POST["miles"];
$price = $_POST["price"];
$dealer = $_POST["dealer"];
$town = $_POST["town"];
$telephone = $_POST["telephone"];
$description = $_POST["description"];
$carindex = $_POST["carindex"];
$region = $_POST["region"];
$image = $_POST["image"];
$id = $_POST["id"];



 $sql=$con->query("INSERT INTO cars (make,model,Reg,colour,miles,price,dealer,town,telephone,description,carindex,region,image,id)Values('[$make]','[$model]','[$Reg]','[$colour]','[$miles]','[$price]','[$dealer]','[$town]','[$telephone]','[$description]','[$carindex]','[$region]','[$image]','[$id]')");

 
if($sql)
{
	echo "Thank You! you are new record.";
	
} else {
	echo "unsucessful please try again later";
}
}
?>
<html 
<head>


</head>

<body>
<form id="form1" name="form1" method="post" action="">
 
  <p>
    <label for="make">
      <div align="center">make</div>
    </label>
    <div align="center">
      <p>
        <input type="text" name="make" id="make" />
      </p>
      <p>model</p>
      <p>
        <input type="text" name="model" id="model" />
      </p>
      <p>Reg</p>
      <p>
        <input type="text" name="Reg" id="Reg" />
      </p>
      <p>colour</p>
      <p>
        <input type="text" name="colour" id="colour" />
      </p>
      <p>
        <label for="miles">miles</label>
      </p>
      <p>
        <input type="text" name="miles" id="miles" />
      </p>
      <p>price</p>
      <p>
        <input type="text" name="price" id="price" />
      </p>
      <p>dealer</p>
      <p>
        <input type="text" name="dealer" id="dealer" />
      </p>
      <p>town</p>
      <p>
        <input type="text" name="town" id="town" />
      </p>
      <p>telephone</p>
      <p>
        <input type="text" name="telephone" id="telephone" />
      </p>
      <p>description</p>
      <p>
        <input type="text" name="description" id="description" />
      </p>
      <p>carindex</p>
      <p>
        <input type="text" name="carindex" id="carindex" />
      </p>
      <p>region</p>
      <p>
        <input type="text" name="region" id="region" />
      </p>
    
  </p>
  <p align="center">image</p>
  <p align="center">
    <input type="text" name="image" id="image" />
  </p>
   </p>
  <p align="center">id</p>
  <p align="center">
    <input type="text" name="id" id="id" />
  </p>
 
  <p align="center">
    <input type="submit" name="submit" id="submit" value="submit" />
  </p>
</form>
</div>
</body>
</html
