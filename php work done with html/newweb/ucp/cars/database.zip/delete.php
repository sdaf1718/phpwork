<?php 

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "cars";

$delete_id = $_GET['del'];

$query = "delete from cars where id='$delete_id'";

if(mysqli_query($query)){
echo "<script>window.open('admin.php?deleted=record has been deleted!!!','_self')</script>";

}

?>